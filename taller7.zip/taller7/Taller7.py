import math

def run():
    x = float(int(input("Escriba un numero: ")))
    es = (0.5 * pow(10,-7)) * 100
    ea = 100
    interacion = 1
    potencia = 2
    valor = 1 - x
    signo = 1
    
    while ea > es:
        if signo == -1:
            operacion = round((valor + pow(x, potencia)) / math.factorial(potencia),7)
            valor = float(operacion)
            print(f'Interacion # {interacion}')
            interacion += 1
            potencia += 1
            signo *= -1
        else:
            operacion = round((valor - pow(x, potencia)) / math.factorial(potencia),7)
            valor = float(operacion)
            print(f'Interacion # {interacion}')
            interacion += 1
            potencia += 1
            signo *= -1

    print(f'El valor final es: {valor}')

if __name__ == "__main__":
    run()