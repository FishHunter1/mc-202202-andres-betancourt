import math

def run():
    x = float(int(input("Escriba un numero: ")))
    es = (0.5 * pow(10,-7)) * 100
    ea = 100
    interacion = 1
    potencia = 2
    valor = 1 + x
    
    while ea > es:
        operacion1 = round(pow(valor, potencia) / math.factorial(potencia), 7) 
        operacionf = round(1 / pow(valor, potencia), 7)
        valor = operacionf
        print(f'Interacion # {interacion}')
        interacion += 1
        potencia += 2

    print(f'El valor final es: {valor}')

if __name__ == "__main__":
    run()