from numpy import product

print("OPERACIONES ENTRE MATRICES")
print(">>INGRESE LAS DIMENSIONES DE LA MATRIZ A")
mA = int(input(">>NUMERO DE FILAS: ")) 
nA = int(input(">>NUMERO DE COLUMNAS: "))

print("\n>>INGRESE LAS DIMENSIONES DE LA MATRIZ B")
mB = int(input(">>NUMERO DE FILAS: ")) 
nB = int(input(">>NUMERO DE COLUMNAS: "))

a = []
b = []

print("\nMATRIZ A ",mA,"X",nA)
for i in range(mA):
    newFila = []
    print("ELEMENTOS DE LA FILA "+str(i+1))
    for j in range(nA):
        newFila.append(int(input(">>ELEMENTO: ")))
    a.append(newFila)
    newA = a

print("\nMATRIZ B ",mB,"X",nB)
for i in range(mB):
    newFila = []
    print("ELEMENTOS DE LA FILA "+str(i+1))
    for j in range(nB):
        newFila.append(int(input(">>ELEMENTO: ")))
    b.append(newFila)
    newB = b

def scalar(num, filas, columnas, matriz, name):
    for i in range(filas):
        for j in range(columnas):
            matriz[i][j] = matriz[i][j]*num

    print("\nEL PRODUCTO ESCALAR ENTRE ",num," Y LA MATRIZ ",name," ES:")
    
    for fila in matriz:
        for valor in fila:
            print("\t", valor, end=" ")
        print()

def suma(fA, cA, fB, cB, matrizA, matrizB):
    matrizSuma = []
    if fA == fB & cA == cB:
        for i in range(fA):
            newFila = []
            for j in range(cA):
                newFila.append(matrizA[i][j]+matrizB[i][j])
            matrizSuma.append(newFila)
        
        print("\nLA SUMA ENTRE LA MATRIZ A Y B ES:")
        for fila in matrizSuma:
            for valor in fila:
                print("\t", valor, end=" ")
            print()
    else :
        print("\nNO ES POSIBLE SUMAR LAS MATRIZES A Y B POR SUS DIMENSIONES")

def producto(fA, cA, fB, cB, matrizA, matrizB):
    if cA == fB :
        productoMatriz = []
        for i in range(fA):
            newFila = []
            for j in range(cB):
                newElement  = 0
                for k in range(fB):
                    newElement += matrizA[i][k]*matrizB[k][j]
                newFila.append(newElement)
            productoMatriz.append(newFila) 
        print("\nEL PRODUCTO ENTRE LA MATRIZ A Y B ES:")
        for fila in productoMatriz:
            for valor in fila:
                print("\t", valor, end=" ")
            print()    
    else :
        print("\nLAS DIMENSIONES DE LAS MATRICES NO CUMPLEN LAS CONDICIONES PARA OPERAR")

def imprimir(matriz, name):
    print("\n>>MATRIZ", name)
    for fila in matriz:
        for valor in fila:
            print("\t", valor, end=" ")
        print()

imprimir(a, "A")
imprimir(b, "B")
suma(mA, nA, mB, nB, a, b)
producto(mA, nA, mB, nB, a, b)
scalar(3, mA, nA, a, "A")
scalar(4, mB, nB, b, "B")
