print("PRODUCTO ESCALAR ENTRE VECTORES")
n = int(input(">>LONGITUD: "))
v1 = []
v2 = []
scalar = 0

for i in range(n):
    v1.append(int(input(">>ELEMENTO VECTOR 1: ")))
    v2.append(int(input(">>ELEMENTO VECTOR 2: ")))

for i in range(n):
    scalar += v1[i]*v2[i]

print("EL PRODUCTO ESCALAR ENTRE EL VECTOR "+str(v1)+" Y "+str(v2)+" ES: "+str(scalar))